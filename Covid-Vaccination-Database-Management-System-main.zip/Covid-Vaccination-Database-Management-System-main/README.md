# Covid-Vaccination-Database-Management-System
The project is based on a database that stores candidate name, age, vaccination status and related information. It maintains the record of vaccinations of the citizens including their past medical history. This database is made for the staff to maintain candidate records. Maintaining a database for such cause is a definite necessary. With the help of technology and computer science such things can be maintained very conveniently.
*Also i would like that I have used an open source html template and modified it according to my project.*
